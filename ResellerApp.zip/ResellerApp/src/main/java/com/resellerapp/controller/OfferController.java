package com.resellerapp.controller;

import com.resellerapp.model.bindings.OfferBindingModel;
import com.resellerapp.model.helpers.LoggedUser;
import com.resellerapp.service.OfferService;
import com.resellerapp.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("/")
public class OfferController {

    private final LoggedUser loggedUser;
    private final OfferService offerService;

    private final UserService userService;

    public OfferController(LoggedUser loggedUser, OfferService offerService, UserService userService) {
        this.loggedUser = loggedUser;
        this.offerService = offerService;
        this.userService = userService;
    }

    @GetMapping("/offer")
    public String offer(Model model) {

        if(!model.containsAttribute("offerBindingModel")) {
            model.addAttribute("offerBindingModel", new OfferBindingModel());
        }

        if(loggedUser.getId() == null) {
            return "redirect:/auth/login";
        }
        return "offer-add";
    }


    @PostMapping("/offer")
    public String addOffer(@Valid @ModelAttribute OfferBindingModel offerBindingModel,
                               BindingResult bindingResult,
                               RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("offerBindingModel", offerBindingModel);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.offerBindingModel", bindingResult);
            return "redirect:login";
        }

        offerService.saveOffer(offerBindingModel);

        return "redirect:/home";
    }


    @GetMapping("/offer/{id}")
    public String buyOffer(@PathVariable("id") Long id) {

        userService.findEntityById(loggedUser.getId()).getBoughtOffers().add(offerService.findById(id));

        return "redirect:/home";
    }
}
