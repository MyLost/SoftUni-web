package com.resellerapp.controller;

import com.resellerapp.model.UserModel;
import com.resellerapp.model.entity.OfferEntity;
import com.resellerapp.model.helpers.LoggedUser;
import com.resellerapp.service.OfferService;
import com.resellerapp.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/")
public class HomeController {

    private final LoggedUser loggedUser;
    private final UserService userService;

    private final OfferService offerService;

    public HomeController(LoggedUser loggedUser, UserService userService, OfferService offerService) {
        this.loggedUser = loggedUser;
        this.userService = userService;
        this.offerService = offerService;
    }

    @GetMapping("/home")
    public String home(Model model) {

        if(loggedUser.getId() == null) {
            return "redirect:/auth/login";
        }

        UserModel userModel = userService.findById(loggedUser.getId());
        List<OfferEntity> userOffers = offerService.findAllByUserId(loggedUser.getId());

        userModel.setOffers(userOffers);

        model.addAttribute("loggedUsername", userModel.getUsername());
        model.addAttribute("userModel", userModel);
        model.addAttribute("allOffers", offerService.findAll());

        return "home";
    }


}
