package com.resellerapp.service;

public interface ConditionService {
}
