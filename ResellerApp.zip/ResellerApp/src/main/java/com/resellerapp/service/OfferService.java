package com.resellerapp.service;

import com.resellerapp.model.bindings.OfferBindingModel;
import com.resellerapp.model.entity.OfferEntity;

import java.util.List;
import java.util.Optional;

public interface OfferService {
    void saveOffer(OfferBindingModel offerBindingModel);

    List<OfferEntity> findAllByUserId(Long id);

    List<OfferEntity> findAll();

    OfferEntity findById(Long id);
}
