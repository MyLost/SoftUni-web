package com.resellerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResellerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ResellerApplication.class, args);
    }
}
