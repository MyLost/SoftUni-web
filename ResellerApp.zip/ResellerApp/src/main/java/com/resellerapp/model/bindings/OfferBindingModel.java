package com.resellerapp.model.bindings;

import com.resellerapp.model.enums.ConditionNames;
import lombok.*;

import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class OfferBindingModel {

    @Size(min = 2, max = 50)
    @NotNull
    private String description;

    @Positive
    @NotNull
    private Double price;

    private ConditionNames condition;

}
