package com.resellerapp.model;

import com.resellerapp.model.entity.OfferEntity;
import lombok.*;

import javax.persistence.Column;
import javax.persistence.OneToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserModel {

    private String username;

    private String email;

    private List<OfferEntity> offers;

    private Set<OfferEntity> boughtOffers;
}
