package com.resellerapp.model.enums;

public enum ConditionNames {
    EXCELLENT, GOOD, ACCEPTABLE
}
