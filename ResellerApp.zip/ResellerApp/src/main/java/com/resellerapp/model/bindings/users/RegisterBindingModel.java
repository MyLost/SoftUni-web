package com.resellerapp.model.bindings.users;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;


@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class RegisterBindingModel {

    @NotNull
    @Length(min=2, message="Username length must be between 3 and 20 characters!")
    private String username;

    @NotNull
    @Email
    private String email;

    @NotNull
    @Length(min=3, message="Username length must be between 3 and 20 characters!")
    private String password;
    @NotNull
    private String confirmPassword;
}
