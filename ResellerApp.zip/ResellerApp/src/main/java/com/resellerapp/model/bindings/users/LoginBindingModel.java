package com.resellerapp.model.bindings.users;

import com.resellerapp.vallidation.checkUserExistance.CheckUserExistence;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@CheckUserExistence
public class LoginBindingModel {

    @NotNull
    @Size(min=3, max=20, message="Username length must be between 3 and 20 characters!")
    private String username;
    @NotNull
    @Size(min=3, max=20, message="Username length must be between 3 and 20 characters!")
    private String password;
}
