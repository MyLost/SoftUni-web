package com.resellerapp.model.entity;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Entity
@Table(name = "offers")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OfferEntity extends BaseEntity {

    @Column(nullable = false)
    @Size(min = 2, max = 50)
    private String description;

    @Column(nullable = false)
    @Positive
    private Double price;

    @ManyToOne
    private UserEntity user;

    @OneToOne
    private ConditionEntity condition;
}
